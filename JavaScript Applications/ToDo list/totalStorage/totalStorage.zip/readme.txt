This year we worked on a cool project (launching mid-2012) to help users plan their finances and retirement. The site involved lots of calculators to capture user data and return estimates for their mortgage, Social Security benefit and other factors they would need to help them plan.

